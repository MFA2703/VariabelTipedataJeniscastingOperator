
package variabeltipedatajeniscastingoperator;


public class VariabelTipedataJeniscastingOperator {

    
    public static void main(String[] args) {
        
        System.out.println("Ringkasan saya mengenai bab Variabel, Tipe data, Jenis casting dan Operator:");
        //Contoh Variabel beserta jenisnya
        byte nomor1 = 100; //tipe data byte berisikan angka -128 ke 127
        short nomor2 = 10200; //tipe data short berisikan angka -32,768 ke 32,767
        int nomor3 = 1200300400; //tipe data int berisikan angka -2,147,483,648 ke 2,147,483,647
        long nomor4 = 1200300400500600700L; //tipe data long berisikan angka -9,223,372,036,854,775,808 ke 9,223,372,036,854,775,807
        float nomorkoma1 = 35e3f; //tipe data float berisikan angka pecahan yang cukup untuk menyimpan 6 sampai 7 angka decimal
        double nomorkoma2 = 12E4d; //tipe data double berisikan angka pecahan yang cukup untuk menyimpan 15 angka decimal
        char huruf = 'A'; //tipe data char adalahkarakter tunggal atau nilai ASCII
        boolean pilihan = true; // tipe data boolean berisikan nilan benar dan salah
        String tulisan = "Halo"; //tipe data string digunakan untuk menyimpan data teks
        
        System.out.println("Output tipe data byte   : " + nomor1);
        System.out.println("Output tipe data short  : " + nomor2);
        System.out.println("Output tipe data int    : " + nomor3);
        System.out.println("Output tipe data long   : " + nomor4);
        System.out.println("Output tipe data float  : " + nomorkoma1);
        System.out.println("Output tipe data double : " + nomorkoma2);
        System.out.println("Output tipe data char   : " + huruf);
        System.out.println("Output tipe data boolean: " + pilihan);
        System.out.println("Output tipe data String : " + tulisan);
        
        //Contoh untuk penggunaan operator + pada variabel
        String NamaAwal = "Muhammad Fazron";
        String NamaAkhir = "Arif";
        String NamaLengkap = NamaAwal + NamaAkhir;
        
        System.out.println("Output operator +String : " + NamaLengkap);
        
        //Contoh penggunaan operator + pada bilangan integer(int)
        int x = 5;
        int y = 7;
        int z = 9;
        
        System.out.println("Output x + y     = " + x + y);
        System.out.println("Output x + y + z = " +x + y + z);
        
        //Contoh tipe casting( Widening casting, Narrowing casting)
        int nomorbulat = 27;
        double nomorkoma = nomorbulat; //Widening Casting(Pelebaran)
        
        double nomerkoma = 3.27;
        int nomerbulat = (int)nomerkoma; //Narrowing Casting(Penyempitan)
        
        System.out.println("Output Casting Pelebaran   : " + nomorkoma);
        System.out.println("Output Casting Penyempitan : " + nomerbulat);
    }   
    
    
}
